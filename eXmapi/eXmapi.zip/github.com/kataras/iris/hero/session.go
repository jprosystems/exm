package hero

// It's so easy, no need to be lived anywhere as built'n.. users should understand
// how easy it's by using it.

// // Session is a binder that will fill a *sessions.Session function input argument
// // or a Controller struct's field.
// func Session(sess *sessions.Sessions) func(context.Context) *sessions.Session {
// 	return sess.Start
// }
