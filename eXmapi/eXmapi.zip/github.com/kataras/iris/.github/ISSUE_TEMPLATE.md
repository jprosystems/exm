Examples for the Iris project can be found at
<https://github.com/kataras/iris/tree/master/_examples>.

Documentation for the Iris project can be found at
<https://godoc.org/github.com/kataras/iris>.

Love iris? Please consider supporting the project:
👉  https://iris-go.com/donate